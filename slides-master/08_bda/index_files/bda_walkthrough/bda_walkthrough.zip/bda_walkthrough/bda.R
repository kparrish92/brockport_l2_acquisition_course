# Useful libraries
library("tidyverse")      # Mainly for ggplot2, dplyr and forcats
library("here")           # Paths
library("lme4")           # Multilevel models
library("brms")           # Bayesian regression models in Stan
library("tidybayes")      # Tidying and ploting posteriors
library("palmerpenguins") # Penguin dataset

#
# Overview
#

# We are going to explore the palmer penguins data set 'penguins' (you might 
# need to install it). 
# Specifically we will use a subset of this data: 
tuxedo_birds <- penguins %>% 
  select(species, bill_depth_mm, body_mass_g) %>% 
  filter(species == c("Chinstrap", "Gentoo")) %>% 
  na.omit() %>% 
  droplevels()

# Take a moment to get to know the data set using your favorite methods. 
# We are particularly interested in predicting body mass as a function 
# species and bill depth. 
# We will slowly build up to that model and make plots along the way. 
# (Note: we will wrecklessly completely disregard priors for now)




# 1. Intercept-only model
#    - Calculate the avg body mass for the entire data set 
#      (keep this value handy)
#    - Fit an intercept-only frequentist model and assess
#    - Fit an intercept-only bayesian model and assess
#    - How do the models compare with each other? And with the avg body mass?
#    - Make a plot of the posterior estimate of the intercept. What does this 
#      represent?











# 2. Add a categorical predictor
#    - Calculate the avg. body mass as a function of species. 
#    - Fit an additive model: body mass as a function of species
#        - Fit the frequentist model first, then the bayesian model
#        - What is the reference level? 
#        - What do the parameter estimates represent?
#    - Try to plot the posterior distribution (forest plot) 
#    - How confident are you that the group difference is != to 0?











# 3. Add the continuous predictor
#    - Again, fit both frequentist and bayesian models with species and 
#      bill_depth_mm as predictors
#    - Compare and interpret both models
#    - Wrangle the posterior distribution to make 1) a forest plot and 2) a 
#      scatterplot (all data plus regression lines) (hard!)










#
# 4. Fit sleepstudy multilevel model (time permitting)
#

