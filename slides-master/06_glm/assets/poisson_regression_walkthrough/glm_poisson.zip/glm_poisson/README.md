# Plan

1. poisson regression walkthrough
2. saving plots
3. 'here' package
4. project structure
5. loading scripts/plots from project into .Rmd files
