# 1. load data



# 2. check structure




# 3. fit inclusive and nested models
#    test for interactions/main effects




# 4. summary of best model




# 5. write up of output



# 6. generate and save plot




