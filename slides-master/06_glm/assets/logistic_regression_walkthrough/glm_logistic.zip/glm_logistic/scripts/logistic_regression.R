library("tidyverse")
library("lingStuff")


# 1. Load the data
# 2. Get to know the data (how many columns? what do they represent?)
# 3. Think of 2 hypotheses you could test
# 4. Fit the appropriate models to test your hypotheses
# 5. Attempt to plot the data (include model fit)




# helpers
# method.args = list(family = "binomial")
# lingStuff::inv_logit()
# inv_logit_manual <- function(x){1 / (1 + exp(-x))}
# inv_logit_manual(coef(mod)[1] + coef(mod)[2] * mean(data$col))
